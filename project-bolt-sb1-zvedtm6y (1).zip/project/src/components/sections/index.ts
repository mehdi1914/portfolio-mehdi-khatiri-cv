export { default as Hero } from './hero/Hero';
export { default as About } from './About';
export { default as Skills } from './Skills';
export { default as Education } from './education/Education';
export { default as Portfolio } from './Portfolio';
export { default as Contact } from './Contact';