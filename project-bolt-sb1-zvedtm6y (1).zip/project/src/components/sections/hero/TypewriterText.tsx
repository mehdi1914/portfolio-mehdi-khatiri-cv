import React from 'react';
import { useTypewriter } from '@/lib/hooks/useTypewriter';

const TYPED_WORDS = [
  "Mehdi Khatiri",
  "a Frontend Developer",
  "a UI/UX Designer",
  "a Problem Solver"
] as const;

export default function TypewriterText() {
  const text = useTypewriter({
    words: TYPED_WORDS,
    typingSpeed: 100,
    pauseTime: 1500
  });

  return (
    <span className="relative inline-block">
      <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
        {text}
      </span>
      <span className="animate-blink ml-1 text-purple-300">|</span>
    </span>
  );
}