import React from 'react';

export default function HeroDescription() {
  return (
    <p className="text-xl md:text-2xl text-purple-200/90 animate-fade-in-delay">
      Building Founder-Focused Digital Experiences
    </p>
  );
}