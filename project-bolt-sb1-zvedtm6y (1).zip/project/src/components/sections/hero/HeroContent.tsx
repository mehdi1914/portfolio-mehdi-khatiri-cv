import React from 'react';
import HeroTitle from './HeroTitle';
import HeroDescription from './HeroDescription';
import HeroActions from './HeroActions';
import SocialLinks from './SocialLinks';

export default function HeroContent() {
  return (
    <div className="text-center space-y-8 max-w-3xl mx-auto animate-fade-in">
      <HeroTitle />
      <HeroDescription />
      <HeroActions />
      <SocialLinks />
    </div>
  );
}